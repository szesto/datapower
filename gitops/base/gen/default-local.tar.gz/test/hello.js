console.log('hello, world...');

